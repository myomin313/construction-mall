<?php

namespace App\Http\Controllers\Admin;
use App\Helper\AndCharacterChanger;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Auth;
use App\BlogCategory;
use App\Freelancer;
use App\Blog;
use App\Advertising;
use App\Helper\AllHelper;
use DB;
use Session;
use Redirect;

class BlogController extends Controller
{
    
      /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addBlog(Request $request){
        $user_id = Auth()->user()->id;
       $freelancer= Freelancer::where('user_id',$user_id)->with('user')->first();
        $advertisings = Advertising::getPageDetailAdvertising(); 
        if(Auth::user()->role == 3){
          return view('admin.blog.freelancer_blog_new',compact('freelancer','advertisings'));  
        }else{
          return view('admin.blog.new',compact('freelancer'));   
        }
    }
    public function blogimageCrop(Request $request){
        $image = $request->image;
       list($type, $image) = explode(';',$image);
        list(, $image)      = explode(',',$image);
        $image = base64_decode($image);
         $image_name= time().'.png';
           $path  = storage_path('app/public/blog/'. $image_name);
        file_put_contents($path, $image);
        return response()->json(['status'=>true,'image_name'=>$image_name]);
    }
       /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function createBlog(Request $request){ 
      
      if ($request->image == "undefined")
        {
            $request['image_name'] = null;
        }
        else
        {
            $request['image_name'] = $request->image;
        }
        
             $status = $this->validation($request);
        if($status->fails())
        {
             $errors =array('errors'=>$status->messages());
             return response()->json($errors);  
        }
        else{
            $blog_url = strtolower(self::makeUrl(trim($request->title)));
            $blog=new Blog;
            $blog->post_user_id = Auth()->user()->id;
            $blog->title =$request->title;
            $blog->image =$request->image;
            $blog->blog_url= $blog_url;
            $description = AndCharacterChanger::replaceChar($request->description);
            $blog->description = $description;
            $blog->blog_category_id =$request->blog_category_id;
            //$blog->save();
            if($blog->save())
            {
                  Session::flash('success', 'Created successfully!'); 
                $success = array('success'=>"Created successfully!");
                return response()->json($success);            
            }else
            {
                $errors = array('errors'=>"Something wrong!");
                return response()->json($errors);
            }
        }

    }
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function blogList(Request $request){
        $data=$request->all();
         $title=$request->title;
               $is_active = $request->is_active;
               $posted_user = $request->posted_user;
               
        $user_id = Auth()->user()->id;
      $freelancer= Freelancer::where('user_id',$user_id)->with('user')->first();
       if(Auth()->user()->role == 3){
         $blogs=Blog::getBlogList($request,$user_id);
       }else{
         $blogs=Blog::getBlogListForAdmin($request);
       }
       
         $advertisings = Advertising::getPageDetailAdvertising();
        if(Auth::user()->role == 3){
           return view('admin.blog.freelancer_blog_list',compact('blogs','freelancer','data','title','is_active','posted_user','advertisings'));  
        }else{
           return view('admin.blog.list',compact('blogs','freelancer','data','title','is_active','posted_user'));   
        }
        
        //return view('');
    }
     /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   public function editBlog($id,$page){
       $id = \Crypt::decrypt($id);
        $page = \Crypt::decrypt($page);

         if(is_numeric($id)){
            Session::put('pageno',$page);
            $user_id = Auth()->user()->id;
            $freelancer= Freelancer::where('user_id',$user_id)->with('user')->first();
        $blog = Blog::where('id',$id)->first();
        // return view('admin.blog.edit',compact('blog','freelancer'));
          $advertisings = Advertising::getPageDetailAdvertising();
         if(Auth::user()->role == 3){
          return view('admin.blog.freelancer_blog_edit',compact('blog','freelancer','advertisings'));  
        }else{
          return view('admin.blog.edit',compact('blog','freelancer'));   
        }
        
         }
        
    }
     /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateBlog(Request $request,$id){
        
        if ($request->image == "undefined")
        {
            $request['image_name'] = null;
        }
        else
        {
            $request['image_name'] = $request->image;
        }
        
           $status = $this->validation($request);
        if($status->fails())
        {
            $errors =array('errors'=>$status->messages());
             return response()->json($errors);  
        }
        else{
            $old_image = $request->old_image;
            $updated_at = date('Y-m-d H:i:s');
            $blog_url = strtolower(self::makeUrl(trim($request->title)));
            $blog = Blog::find($id);
            $blog->title =$request->title;
            $blog->image =$request->image_name;
            $blog->blog_url =$blog_url;
            $blog->updated_at = $updated_at;
            $description = AndCharacterChanger::replaceChar($request->description);
            $blog->description = $description;
            $blog->blog_category_id =$request->blog_category_id;
         
            if($blog->save())
            {
                    
                if( $request->image != $request->old_image){
                    if(Storage::disk('public')->exists('/blog/'.$request->old_image)){
                  unlink(storage_path('app/public/blog/'.$request->old_image));
                    }
                } 
                Session::flash('success', 'Updated Successfully!'); 
                $success = array('success'=>"Successfully saved changes!");
                return response()->json($success);            
            }else
            {
                $errors = array('errors'=>"Something wrong!");
                return response()->json($errors);
            }
        }  

    }
    private function validation($request)
    {
        $messages = [
            'title.required' => 'Blog Title is required',
            'image_name.required' => 'Image is required',
            'description.required' => 'Blog Description is required',
            'blog_category_id.required' => 'Blog Category is required',
        ];

        $validator = Validator::make($request->all(), [
                'title' => "required",
                'image_name'=>"required",
                'description'=>"required",
                'blog_category_id'=>"required",
            ], $messages);
        return $validator;  
    }
     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteBlog($id){
         $blog = Blog::findOrFail($id);
        if(Storage::disk('public')->exists('/blog/'.$blog->image))
            unlink(storage_path('app/public/blog/'.$blog->image));
        $blog->delete();
        return Redirect::back();
        
    }
     //update Quotaion status record
     public function updateBlogStatus(Request $request){
       $result = AllHelper::approveStatus($request,'App\Blog');
       return response()->json($result);

    }
    public static function makeUrl( $string ) 
    {
          $stripArr = array( '(', ')','{','}','[',']','','  ','_',
                          '!','-','&','<','>','<','\\','/',
                          '|','+','-',':',',','`','@','#','$',
                          '%','^','&','+','*','.','=','-','~','"','\''
          );
          $result = str_replace($stripArr,' ', $string); 
          return preg_replace('# {1,}#', '-', trim($result));
    }

 public function storesession(Request $request){
        //dd($request->id);exit();
          Session::put('blogcheck',$request->ids);
        
    }
    public function deleteall(Request $request){
        $result = AllHelper::deleteAll($request,'App\Blog');
       return response()->json($result);
    }
}
