<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryFreelancer extends Model
{
    protected $fillable = ['category_name'];
    
}
